from person_class import Person

class Student (Person):
  def __init__(self, first_name, last_name):
    super().__init__(first_name, last_name)
    self._knowledge = []

  def learn(self, string):
    self._knowledge.append(string)

  def __len__(self):
    return len(self._knowledge)
  
  def forget(self, string):
      if string in self._knowledge:
          self._knowledge.remove(string)
from person_class import Person
import random

class Instructor(Person):

    def __init__(self, first_name, last_name):
        super().__init__(first_name, last_name)
        self._knowledge = [
            "str is a data type in python",
            "programming is hard, but it's worth it",
            "Javascript async web request",
            "Python function call definition",
            "object-oriented teacher instance",
            "programming computers hacking learning terminal",
            "pipenv install pipenv shell",
            "pytest -x flag to fail fast"
        ]

    @property
    def knowledge(self):
        return self._knowledge

    @knowledge.setter
    def knowledge(self, topic):
        self._knowledge.append(topic)


    def teach(self):
      if len(self._knowledge) > 0:
        tmp = random.randint(0,len(self._knowledge)-1)
        return self._knowledge[tmp]
      else:
        print(name, " has nothing to teach.")

    def __iter__(self):
      for skill in sorted(self._knowledge):
        yield skill

    
    def __contains__(self, skill):
      return skill in self._knowledge
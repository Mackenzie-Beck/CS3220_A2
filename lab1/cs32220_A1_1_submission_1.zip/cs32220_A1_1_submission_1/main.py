from person_class import Person
from instructor_class import Instructor
from student_class import Student

def main():
    # Test Person class
    person = Person("John", "Doe")
    print("Person: ", person.first_name, " ", person.last_name)

    # Test Instructor class
    instructor = Instructor("Alice", "Smith")
    print(f"Instructor: {instructor.first_name} {instructor.last_name}")
    
    print("Instructor's knowledge:")
    for skill in instructor:
        print(skill)
    
    print(f"Instructor knows 'Python function call definition': {'Python function call definition' in instructor}")
    print(f"Instructor knows 'Some other skill': {'Some other skill' in instructor}")
    
    print("Instructor teaches:")
    for _ in range(3):
        print(instructor.teach())
    
    print(f"Instructor learns a new topic")
    instructor.knowledge = "New topic"
    
    print("Updated Instructor's knowledge:")
    for skill in instructor:
        print(skill)
    
    # Test Student class
    student = Student("Bob", "Smith")
    print(f"Student: {student.first_name} {student.last_name}")
    
    print(f"Student's knowledge length: {len(student)}")
    
    print("Student learns new topics")
    student.learn("Topic 1")
    student.learn("Topic 2")
    
    print(f"Updated Student's knowledge length: {len(student)}")

if __name__ == "__main__":
    main()
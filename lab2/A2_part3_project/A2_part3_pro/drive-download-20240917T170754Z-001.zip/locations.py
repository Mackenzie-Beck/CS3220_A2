# These are the 4 locations for the 4-state environment
loc_A, loc_B, loc_C, loc_D = (0, 0), (1, 0), (1,0),(1,1)
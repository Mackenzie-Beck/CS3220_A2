'''Randomly choose one of the actions from the vacuum environment'''
from agentPrograms import *
from agentClass import Agent
from thingClass import Thing
from data import *
from rules import *

def RandomVacuumAgent():
    return Agent(RandomAgentProgram(actionList))


def TableDrivenVacuumAgent():
     return Agent(TableDrivenAgentProgram(table))

def ReflexAgent() :
  return Agent(ReflexAgentProgram(agentRules,interpret_input,rule_match))


def ReflexAgentA2pro() :
  return Agent(ReflexAgentProgram(a2proRules,interpret_input_A2pro,rule_match_A2pro))


class OfficeManager(Thing):
  pass

class ITStuff(Thing):
  pass

class Student(Thing):
  pass
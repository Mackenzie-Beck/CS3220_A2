agentRules={((0, 0), 'Dirty'): 'Suck', 
((1, 0), 'Dirty'): 'Suck', 
((0, 0), 'Clean'): 'Right',
((1, 0), 'Clean'): 'Left'}
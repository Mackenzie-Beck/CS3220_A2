# These are the two locations for the two-state environment
loc_A, loc_B = (0, 0), (1, 0)
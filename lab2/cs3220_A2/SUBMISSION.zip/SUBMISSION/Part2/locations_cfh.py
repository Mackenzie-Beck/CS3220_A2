# These are the locations for the cat-friendly house
room1, room2, room3 = 1, 2, 3

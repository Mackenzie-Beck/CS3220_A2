# directions for reflex agent
# Left and right directions for reflex agent
left = "Left"
right = "Right"
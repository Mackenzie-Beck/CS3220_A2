# These are the 4 locations for the 4-state environment
#loc_A, loc_B, loc_C, loc_D = (0, 0), (1, 0), (1,0),(1,1)




# these are the locations for the company specified in part 3

Room1_A, Room1_B, Room1_C, Room2_A, Room2_B, Room2_C = (0,0), (0,1), (0,2), (1,0), (1,1), (1,2)
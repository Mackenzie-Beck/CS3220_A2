from directions import *

a2proRules={'Office manager': 'Give mail', 
'IT': 'Give donuts', 
'Student':'Give pizza',
'Clear':'Go ahead',
'Last room':'Stop'
}






a2p3Rules = {
    'Office manager': 'Give mail',
    'IT': 'Give donuts',
    'Student': 'Give pizza',
    'Clear': 'Go forward',
    'Last room': 'Stop',
}


# These are the two locations for the two-state environment
loc_A, loc_B, loc_C, loc_D, loc_E = (0, 0), (0, 1), (0, 2), (0, 3), (0, 4)
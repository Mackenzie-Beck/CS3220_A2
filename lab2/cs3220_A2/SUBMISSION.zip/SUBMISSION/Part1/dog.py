from thingClass import Thing

class Dog(Thing):
    def __init__(self):
        self.alive = True
        self.name = 'dog'
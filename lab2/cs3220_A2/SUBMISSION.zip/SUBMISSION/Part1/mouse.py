from thingClass import Thing

class Mouse(Thing):
    def __init__(self):
        self.alive = True
        self.name = 'mouse'